from pybrain.optimization.populationbased.multiobjective.nsga2 import MultiObjectiveGA
""" added by JPQ """
from pybrain.optimization.populationbased.multiobjective.constnsga2 import ConstMultiObjectiveGA
# ---