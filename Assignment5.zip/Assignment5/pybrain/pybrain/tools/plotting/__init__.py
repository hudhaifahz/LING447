#from fitnesslandscapes import FitnessPlotter
from .multiline import MultilinePlotter
from .colormaps import ColorMap
from .fitnessprogression import plotFitnessProgession