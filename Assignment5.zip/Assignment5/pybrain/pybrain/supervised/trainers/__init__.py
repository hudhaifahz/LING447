from pybrain.supervised.trainers.trainer import Trainer
from pybrain.supervised.trainers.backprop import BackpropTrainer
from pybrain.supervised.trainers.rprop import RPropMinusTrainer
