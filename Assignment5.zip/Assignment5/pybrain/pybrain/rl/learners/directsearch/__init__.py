from pybrain.rl.learners.directsearch.rwr import RWR
from pybrain.rl.learners.directsearch.enac import ENAC
from pybrain.rl.learners.directsearch.reinforce import Reinforce

# TODO: also black-box optimizers -- but this leads to circular imports...
# from pybrain.optimization.__init__ import *
