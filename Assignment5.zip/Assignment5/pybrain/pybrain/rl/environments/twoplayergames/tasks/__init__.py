from pybrain.rl.environments.twoplayergames.tasks.capturetask import CaptureGameTask
from pybrain.rl.environments.twoplayergames.tasks.handicaptask import HandicapCaptureTask
from pybrain.rl.environments.twoplayergames.tasks.relativetask import RelativeCaptureTask
from pybrain.rl.environments.twoplayergames.tasks.gomokutask import GomokuTask
from pybrain.rl.environments.twoplayergames.tasks.relativegomokutask import RelativeGomokuTask
from pybrain.rl.environments.twoplayergames.tasks.pentetask import PenteTask
